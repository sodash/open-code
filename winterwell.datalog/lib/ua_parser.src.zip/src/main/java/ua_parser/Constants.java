package ua_parser;

/**
 * @author sojern
 */
public class Constants {
  public static final String EMPTY_STRING = "\"\"";
}
